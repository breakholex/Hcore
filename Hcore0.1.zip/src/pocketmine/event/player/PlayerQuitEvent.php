<?php

/*
****************************************
██╗  ██╗ █████╗  █████╗ ██████╗ ███████╗
██║  ██║██╔══██╗██╔══██╗██╔══██╗██╔════╝
███████║██║  ╚═╝██║  ██║██████╔╝█████╗
██╔══██║██║  ██╗██║  ██║██╔══██╗██╔══╝
██║  ██║╚█████╔╝╚█████╔╝██║  ██║███████╗
╚═╝  ╚═╝ ╚════╝  ╚════╝ ╚═╝  ╚═╝╚══════╝
*********** Server : HyBitch ***********
*/

declare(strict_types = 1);

namespace pocketmine\event\player;

use pocketmine\event\TranslationContainer;
use pocketmine\Player;

/**
 * Called when a player leaves the server
 */
class PlayerQuitEvent extends PlayerEvent{
	public static $handlerList = null;

	/** @var TranslationContainer|string */
	protected $quitMessage;

	/**
	 * @param Player                      $player
	 * @param TranslationContainer|string $quitMessage
	 */
	public function __construct(Player $player, $quitMessage){
		$this->player = $player;
		$this->quitMessage = $quitMessage;
	}

	/**
	 * @param TranslationContainer|string $quitMessage
	 */
	public function setQuitMessage($quitMessage){
		$this->quitMessage = $quitMessage;
	}

	/**
	 * @return TranslationContainer|string
	 */
	public function getQuitMessage(){
		return $this->quitMessage;
	}
}
