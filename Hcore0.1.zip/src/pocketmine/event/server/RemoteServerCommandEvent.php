<?php

/*
****************************************
██╗  ██╗ █████╗  █████╗ ██████╗ ███████╗
██║  ██║██╔══██╗██╔══██╗██╔══██╗██╔════╝
███████║██║  ╚═╝██║  ██║██████╔╝█████╗
██╔══██║██║  ██╗██║  ██║██╔══██╗██╔══╝
██║  ██║╚█████╔╝╚█████╔╝██║  ██║███████╗
╚═╝  ╚═╝ ╚════╝  ╚════╝ ╚═╝  ╚═╝╚══════╝
*********** Server : HyBitch ***********
*/

declare(strict_types = 1);

namespace pocketmine\event\server;

use pocketmine\command\CommandSender;

/**
 * This event is called when a command is received over RCON.
 */
class RemoteServerCommandEvent extends ServerCommandEvent{
	public static $handlerList = null;

	/**
	 * @param CommandSender $sender
	 * @param string        $command
	 */
	public function __construct(CommandSender $sender, string $command){
		parent::__construct($sender, $command);
	}

}