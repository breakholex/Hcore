<?php

/*
****************************************
██╗  ██╗ █████╗  █████╗ ██████╗ ███████╗
██║  ██║██╔══██╗██╔══██╗██╔══██╗██╔════╝
███████║██║  ╚═╝██║  ██║██████╔╝█████╗
██╔══██║██║  ██╗██║  ██║██╔══██╗██╔══╝
██║  ██║╚█████╔╝╚█████╔╝██║  ██║███████╗
╚═╝  ╚═╝ ╚════╝  ╚════╝ ╚═╝  ╚═╝╚══════╝
*********** Server : HyBitch ***********
*/

declare(strict_types = 1);

namespace pocketmine\command;


interface CommandExecutor{

	/**
	 * @param CommandSender $sender
	 * @param Command       $command
	 * @param string        $label
	 * @param string[]      $args
	 *
	 * @return bool
	 */
	public function onCommand(CommandSender $sender, Command $command, string $label, array $args) : bool;

}