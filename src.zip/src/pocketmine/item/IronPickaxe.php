<?php

/*
****************************************
██╗  ██╗ █████╗  █████╗ ██████╗ ███████╗
██║  ██║██╔══██╗██╔══██╗██╔══██╗██╔════╝
███████║██║  ╚═╝██║  ██║██████╔╝█████╗
██╔══██║██║  ██╗██║  ██║██╔══██╗██╔══╝
██║  ██║╚█████╔╝╚█████╔╝██║  ██║███████╗
╚═╝  ╚═╝ ╚════╝  ╚════╝ ╚═╝  ╚═╝╚══════╝
*********** Server : HyBitch ***********
*/

declare(strict_types = 1);

namespace pocketmine\item;


class IronPickaxe extends Tool{
	public function __construct($meta = 0, $count = 1){
		parent::__construct(self::IRON_PICKAXE, $meta, $count, "Iron Pickaxe");
	}

	public function isPickaxe(){
		return Tool::TIER_IRON;
	}

	public function getAttackPoints() : int{
		return 4;
	}
}