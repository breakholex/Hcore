<?php

/*
****************************************
██╗  ██╗ █████╗  █████╗ ██████╗ ███████╗
██║  ██║██╔══██╗██╔══██╗██╔══██╗██╔════╝
███████║██║  ╚═╝██║  ██║██████╔╝█████╗
██╔══██║██║  ██╗██║  ██║██╔══██╗██╔══╝
██║  ██║╚█████╔╝╚█████╔╝██║  ██║███████╗
╚═╝  ╚═╝ ╚════╝  ╚════╝ ╚═╝  ╚═╝╚══════╝
*********** Server : HyBitch ***********
*/

declare(strict_types = 1);

namespace pocketmine\event\entity;

use pocketmine\entity\EnderPearl;
use pocketmine\entity\Entity;
use pocketmine\event\Cancellable;
use pocketmine\level\Position;

class EntityEnderPearlEvent extends EntityEvent implements Cancellable{
	public static $handlerList = null;

	private $projectile;

	public function __construct(Entity $entity, EnderPearl $projectile){
		$this->entity = $entity;
		$this->projectile = $projectile;
	}

	public function getEnderPearl(){
		return $this->projectile;
	}


}