<?php

/*
****************************************
██╗  ██╗ █████╗  █████╗ ██████╗ ███████╗
██║  ██║██╔══██╗██╔══██╗██╔══██╗██╔════╝
███████║██║  ╚═╝██║  ██║██████╔╝█████╗
██╔══██║██║  ██╗██║  ██║██╔══██╗██╔══╝
██║  ██║╚█████╔╝╚█████╔╝██║  ██║███████╗
╚═╝  ╚═╝ ╚════╝  ╚════╝ ╚═╝  ╚═╝╚══════╝
*********** Server : HyBitch ***********
*/

declare(strict_types = 1);

namespace pocketmine\event\plugin;

class PluginDisableEvent extends PluginEvent{
	public static $handlerList = null;

}
